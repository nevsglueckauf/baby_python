```mermaid

sequenceDiagram
    Bot ->> User: Hallo User, wie geht es Dir?
    Note right of User: Beispieldialog
    User--x Bot: Ach es geht so ...
    Bot ->> User: Kann ich Dir helfen, das zu ändern?
    User-->Bot: Ach, ich weiß es nicht..
    
    
```
