print('Hello, world')

# VS Code Ext. Markdown Preview Mermaid Support