# chatbot
Projektarbeit Python 2025-I

Ziele: möglichst viele bisher behandelte Aspekte von Python wiederholen

- Klassen definieren und Objekte nutzen
    - RegEx (reguläre Ausdrücke )

- Verzicht auf alle Libs, die nicht zur Python Standard Library gehören --> mitjeder Python Runtime ausführbar

## Appendix

## Beispiel-Dialog

```mermaid

sequenceDiagram
    Bot ->> User: Hallo User, wie geht es Dir?
    Note right of User: Beispieldialog
    User--x Bot: Ach es geht so ...
    Bot ->> User: Kann ich Dir helfen, das zu ändern?
    User-->Bot: Ach, ich weiß es nicht..
    
    
```